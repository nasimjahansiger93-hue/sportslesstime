const matches = [
  {sport:"Cricket", status:"UPCOMING", home:"Bangladesh", away:"Opposition", homeIcon:"🇧🇩", awayIcon:"🏏", time:"Fixture to be confirmed", detail:"International cricket"},
  {sport:"Football", status:"UPCOMING", home:"Home Team", away:"Away Team", homeIcon:"🔴", awayIcon:"⚽", time:"Fixture to be confirmed", detail:"Football match"},
  {sport:"Tennis", status:"UPCOMING", home:"Player One", away:"Player Two", homeIcon:"🎾", awayIcon:"🎾", time:"Schedule to be confirmed", detail:"Tennis match"},
  {sport:"Cricket", status:"UPCOMING", home:"Team Alpha", away:"Team Beta", homeIcon:"🏏", awayIcon:"🏏", time:"Fixture to be confirmed", detail:"Cricket match"},
  {sport:"Football", status:"UPCOMING", home:"Club One", away:"Club Two", homeIcon:"⚽", awayIcon:"⚽", time:"Fixture to be confirmed", detail:"League match"},
  {sport:"Cricket", status:"UPCOMING", home:"Team Red", away:"Team Blue", homeIcon:"🔴", awayIcon:"🔵", time:"Fixture to be confirmed", detail:"Domestic cricket"}
];
const matchGrid = document.getElementById("matchGrid");
function renderMatches(filter="all") {
  const shown = matches.filter(m => filter === "all" || m.sport === filter);
  matchGrid.innerHTML = shown.map(m => `<article class="match-card">
    <div class="match-top"><span class="sport-label">${m.sport.toUpperCase()}</span><span class="match-status">${m.status}</span></div>
    <div class="teams"><div class="team"><span class="team-badge">${m.homeIcon}</span>${m.home}</div><span class="versus">VS</span><div class="team"><span class="team-badge">${m.awayIcon}</span>${m.away}</div></div>
    <div class="match-foot"><span>${m.detail}</span><strong>${m.time}</strong></div>
  </article>`).join("");
}
renderMatches();
document.querySelectorAll(".filter").forEach(button => button.addEventListener("click", () => {
  document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
  button.classList.add("active");
  renderMatches(button.dataset.filter);
}));
const fixtureRows = [
  ["DATE TBC","Bangladesh","Opposition","CRICKET"],
  ["DATE TBC","Home Team","Away Team","FOOTBALL"],
  ["DATE TBC","Player One","Player Two","TENNIS"],
  ["DATE TBC","Team Alpha","Team Beta","CRICKET"]
];
document.getElementById("fixtureList").innerHTML = fixtureRows.map(f => `<div class="fixture-row"><div class="fixture-date"><strong>${f[0]}</strong>Time TBC</div><div class="fixture-teams">${f[1]} <span>VS</span> ${f[2]}</div><div class="fixture-type">${f[3]}</div></div>`).join("");
const now = new Date();
document.getElementById("today").textContent = now.toLocaleDateString("en-GB",{weekday:"short",day:"2-digit",month:"short",year:"numeric"}).toUpperCase();
document.getElementById("year").textContent = now.getFullYear();
const toggle = document.getElementById("menuToggle");
const nav = document.getElementById("mainNav");
toggle.addEventListener("click", () => {
  const opened = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", String(opened));
});
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  nav.classList.remove("open");
  toggle.setAttribute("aria-expanded","false");
}));
