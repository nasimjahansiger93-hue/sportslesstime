# SportsLessTime

A responsive black-and-red sports website starter built with plain HTML, CSS and JavaScript.

## Files
- `index.html` — page structure and content
- `style.css` — responsive styling
- `script.js` — demo match cards, filters, fixture list, date and mobile menu

## Publish with GitHub Pages
1. Create a **public** repository named `sportslesstime` (or use your preferred repository name).
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish and use the URL shown in Settings → Pages.

## Important
The match cards and fixtures are placeholders, not live scores. To show real scores, connect a licensed sports API. Do not put private API keys in browser JavaScript; use a secure backend or serverless function for secrets. Check the API provider's pricing, rate limits, attribution and usage terms before connecting it.
